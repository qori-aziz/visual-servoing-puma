# Purple Ball > V1.0.0
https://universe.roboflow.com/itb-anfcb/purple-ball

Provided by a Roboflow user
License: CC BY 4.0

